#!/usr/bin/perl
use strict;
use warnings;
my @infiles=glob("*_sitewise_lnL.txt");
foreach my $infile (@infiles) {
  next unless $infile=~m/(?<branch>.+?)_Gene_(?<gene>.+?)_sitewise_lnL.txt/gi;
  my $branch_id=$+{branch};
  my $gene_id=$+{gene};
  my %hash;
  my $tree_no;
  print "$branch_id\t$gene_id\n";  
  open (MATCHIN, $infile) or die "Can't open the file $infile: $!";
  while (my $content=<MATCHIN>) { 
	chomp $content;
    my @elements=split(/\t+/,$content);
    my $best_tree=$elements[3];
	my @trees=split(/\s+/,$elements[4]);
    $tree_no=scalar @trees;
	my $site_signal;
	if ($tree_no==3) {$site_signal=(abs($elements[5]-$elements[6])+abs($elements[5]-$elements[7])+abs($elements[6]-$elements[7]))/3;}
	elsif ($tree_no==2) {$site_signal=abs($elements[5]-$elements[6])};
	@{$hash{$elements[1]}}=($site_signal, $best_tree);
   }
   close MATCHIN;

 if ($tree_no>3) { print "Please edit the scripts, since they only accept no more than 3 hypotheses";}

 if ($tree_no==2) {
   my $t1_0_no=0;
   my $t2_0_no=0;
   my $t1_weak_no=0;
   my $t2_weak_no=0;
   my $t1_strong_no=0;
   my $t2_strong_no=0;
   foreach  my $site( sort { $a <=> $b } keys %hash) {	
	   if ($hash{$site}[1] eq "tr1") {$t1_0_no++;}
	   if ($hash{$site}[1] eq "tr2") {$t2_0_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]<=0.5) {$t1_weak_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]<=0.5) {$t2_weak_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]>0.5) {$t1_strong_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]>0.5) {$t2_strong_no++;}

   }
   my $output= "${branch_id}_sitewise_statictics.table";
   open (OUT,">>", $output) or die "Can't write the file $output: $!";
   print OUT "$gene_id\tall\ttr1 tr2\t$t1_0_no\t$t2_0_no\n";
   print OUT "$gene_id\tweak\ttr1 tr2\t$t1_weak_no\t$t2_weak_no\n";
   print OUT "$gene_id\tstrong\ttr1 tr2\t$t1_strong_no\t$t2_strong_no\n";
   close OUT;
 }

 if ($tree_no==3) {
   my $t1_0_no=0;
   my $t2_0_no=0;
   my $t3_0_no=0;
   my $t1_weak_no=0;
   my $t2_weak_no=0;
   my $t3_weak_no=0;
   my $t1_strong_no=0;
   my $t2_strong_no=0;
   my $t3_strong_no=0;
   foreach  my $site( sort { $a <=> $b } keys %hash) {	
	   if ($hash{$site}[1] eq "tr1") {$t1_0_no++;}
	   if ($hash{$site}[1] eq "tr2") {$t2_0_no++;}
	   if ($hash{$site}[1] eq "tr3") {$t3_0_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]<=0.5) {$t1_weak_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]<=0.5) {$t2_weak_no++;}
	   if ($hash{$site}[1] eq "tr3" && @{$hash{$site}}[0]<=0.5) {$t3_weak_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]>0.5) {$t1_strong_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]>0.5) {$t2_strong_no++;}
	   if ($hash{$site}[1] eq "tr3" && @{$hash{$site}}[0]>0.5) {$t3_strong_no++;}
   }
   my $output= "${branch_id}_sitewise_statictics.table";
   open (OUT,">>", $output) or die "Can't write the file $output: $!";
   print OUT "$gene_id\tall\ttr1 tr2 tr3\t$t1_0_no\t$t2_0_no\t$t3_0_no\n";
   print OUT "$gene_id\tweak\ttr1 tr2 tr3\t$t1_weak_no\t$t2_weak_no\t$t3_weak_no\n";
   print OUT "$gene_id\tstrong\ttr1 tr2 tr3\t$t1_strong_no\t$t2_strong_no\t$t3_strong_no\n";
   close OUT;
 }


}


 