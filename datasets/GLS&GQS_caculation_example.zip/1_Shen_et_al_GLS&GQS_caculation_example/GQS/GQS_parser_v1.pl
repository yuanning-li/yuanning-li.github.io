#!/usr/bin/perl
use strict;
use warnings;
#usage: perl GQS_parser_v1.pl gt_extension=.fasta.treefile ML_T1.tre ASTRAL_T2.tre ML2ASTRAL_GQS#
my $start_time=time;
my $gene_tree=$ARGV[0]; # gene_tree_file#
my $concatenation_tree_t1=$ARGV[1]; # concatenation-based tree (T1) filename"#
my $coalecent_tree_t2=$ARGV[2]; #coalecent-based tree (T2) filename"#
my $out_file=$ARGV[3]; #  output filename #
$gene_tree=~s/\w+=//i;
$concatenation_tree_t1=~s/\w+=//i;
$coalecent_tree_t2=~s/\w+=//i;

my ($conca_t1_tree,$conca_t1_tip)=tree_parse($concatenation_tree_t1);
my ($coale_t2_tree,$coale_t2_tip)=tree_parse($coalecent_tree_t2);
my %conca_t1_tip_hash=%$conca_t1_tip;
my %coale_t2_tip_hash=%$coale_t2_tip;
#print "$$conca_t1_tree\n";
#print "$$coale_t2_tree\n";
my $outputs="${out_file}_table.txt";
open (OUTPUT,">>", $outputs) or die "Can't write the file $outputs: $!";
#print OUTPUT "gene_id\ttree_supported\ttr1_GQS\ttr2_GQS\tdf_GQS\n";

if (%conca_t1_tip_hash~~%coale_t2_tip_hash) {
  my $tips_no_in_ref=scalar keys %conca_t1_tip_hash;
# $file_extension_gt=~s/gt_extension=//i;
 # my @gene_trees=glob("./gene_trees/*$file_extension_gt");
  #foreach my $gene_tree (sort @gene_trees) {
	 #next unless $gene_tree=~m/.*\/(?<gt_id>.*)$file_extension_gt/ig;
	 my $gene_tree_id=$gene_tree;

	 my $gt_unfound_tip="no";
	 my ($gt_tree,$gt_tip)=tree_parse($gene_tree);
     my %gt_tip_hash=%$gt_tip;
	 foreach my $gt_tip_name (keys %gt_tip_hash) {
		unless (exists $conca_t1_tip_hash{$gt_tip_name}) { $gt_unfound_tip="yes";last;}
	 }

	 if ($gt_unfound_tip eq "no") {
       # print "$gene_tree_id\t$tips_no_in_ref\n";
		my ($gene_t1_QS)=astral_QS($gene_tree_id,$tips_no_in_ref,$$conca_t1_tree,$$gt_tree,"T1");
		print "$gene_tree_id\tT1\t$$gene_t1_QS\n";
		my ($gene_t2_QS)=astral_QS($gene_tree_id,$tips_no_in_ref,$$coale_t2_tree,$$gt_tree,"T2");
		print "$gene_tree_id\tT2\t$$gene_t2_QS\n";
		if ($$gene_t1_QS ne "NA" and $$gene_t2_QS ne "NA") {
         if ($$gene_t1_QS>$$gene_t2_QS ) {print OUTPUT "$gene_tree_id\ttr1\t$$gene_t1_QS\t$$gene_t2_QS\t",$$gene_t1_QS-$$gene_t2_QS,"\n";}
	     elsif ($$gene_t2_QS>$$gene_t1_QS ) {print OUTPUT "$gene_tree_id\ttr2\t$$gene_t1_QS\t$$gene_t2_QS\t",$$gene_t1_QS-$$gene_t2_QS,"\n";}
	     elsif ($$gene_t2_QS==$$gene_t1_QS ) {print OUTPUT "$gene_tree_id\tambiguity\t$$gene_t1_QS\t$$gene_t2_QS\t",$$gene_t1_QS-$$gene_t2_QS,"\n";}
	   }else{print OUTPUT "$gene_tree_id\tNA\t$$gene_t1_QS\t$$gene_t2_QS\tNA\n";}
	 }else{print "$concatenation_tree_t1 has a different set of tips relative to $coalecent_tree_t2\n";}
# }
}else{print "$concatenation_tree_t1 has a different set of tips relative to $coalecent_tree_t2\n"; }

close OUTPUT;

sub tree_parse {
	my $tree_file=shift;
	my %tip_hash;
	my $newick_tree='';
    open (MATCHIN, $tree_file) or die "Can't open the file $tree_file: $!";
    while (my $content=<MATCHIN>) { 
      chomp $content;
	  next unless $content=~m/(?<new>.*;)/ig;
	   $newick_tree=$+{new};
	   my $new_info=$+{new};
	   $new_info=~s/(.*)\;$/$1/gi;
	   $new_info=~s/\):[A-Za-z0-9\.-]+/\)/gi;  # remove internal branch length #
	   $new_info=~s/\)[0-9\.-]+:[A-Za-z0-9\.-]+/\)/gi; # remove internal branch length and support #
	   $new_info=~s/\)[0-9\.-]+/\)/gi; # remove internal support #
	   $new_info=~s/:[A-Za-z0-9\.-]+,/,/gi; # remove external branch length #
	   $new_info=~s/:[A-Za-z0-9\.-]+\)/\)/gi; # remove external branch length #
	   $new_info=~s/\)//gi;
	   $new_info=~s/\(//gi;

	   my @tips=split(/,/,$new_info);
	   foreach my $tip_long (sort @tips) {
		   if ($tip_long=~m/[A-Za-z0-9]/i) {$tip_hash{$tip_long}=1;}
	   }

	 last;		 
    }
    close MATCHIN;
  return (\$newick_tree,\%tip_hash);
}
 my @files_delted;
sub astral_QS {
	  
        my ($gene_name,$ref_tips_no,$ref,$gt,$ref_name)=@_;
        my $current_time=time;
		my $gt_dummy="${gene_name}_vs_$ref_name.dummy";
		open (OUTPUT1,">>",$gt_dummy) or die "Can't write the file $gt_dummy: $!";
        print OUTPUT1 "$ref\n$gt\n";
	    close OUTPUT1;
		my $dummy_file=$gt_dummy;
		push @files_delted,$gt_dummy;
		my $gt_ref="${gene_name}_vs_$ref_name.ref";
		open (OUTPUT2,">>", $gt_ref) or die "Can't write the file $gt_ref: $!";
        print OUTPUT2 "$ref\n";
	    close OUTPUT2;
		my $cmd_line="java -jar ./program/astral.5.6.3.jar -i $gt_dummy -q $gt_ref > ${gene_name}_vs_${ref_name}_QS.log 2>&1";
		#print "$cmd_line\n";
        system ("$cmd_line");
		my $ref_gt_file=$gt_ref;
		push @files_delted,$gt_ref;

	  my $astral_score="0";
      my $no_taxa=$ref_tips_no;
	  my $dummy_QS=$no_taxa*($no_taxa-1)*($no_taxa-2)*($no_taxa-3)/24;

	  my $astral_log_file="${gene_name}_vs_${ref_name}_QS.log";
      open (IN, $astral_log_file) or die "Can't open the file $astral_log_file: $!";
      while (my $content=<IN>) { 
	     chomp $content;
         next unless $content=~s/^Final quartet score is:\s+([-\d\.]+)/$1/gi;
	     $astral_score=$content;
      }
     close IN;
	 my $log_file=$astral_log_file;
	 push @files_delted,$astral_log_file;

	 my $gt_net_QS=$astral_score-$dummy_QS;
     my $gt_QS_update;
	 if ($gt_net_QS<0) {$gt_QS_update="NA";
	 }else{$gt_QS_update=$gt_net_QS;}
    #print "$astral_score\t$gt_QS_update\n";
	 #system ("rm $gt_dummy");
	 #system ("rm $gt_ref");
	 #system ("rm $astral_log_file");
	 return (\$gt_QS_update);
	 
}

unlink @files_delted;
print "done\n";

my $end_time=time;
my $duration=($end_time-$start_time)/60;
print"Execution time: $duration min.\n";
