#!/usr/bin/perl
use strict;
use warnings;
#usage: perl GLS_parser_v1.pl RAxML_perSiteLLs.ML2ASTRAL 37taxa_1245genes_combine_orders.txt.reduced ML2ASTRAL_GLS#
my $start_time=time;
my $infile=$ARGV[0]; # Site_wise loglikelihood file estimated from RAxML #
my $gene_boundary=$ARGV[1]; # Gene-based partition file in RAxML-style #
my $out_file=$ARGV[2]; #  prefix for outfile(s) #
#next unless $infile=~m/RAxML_perSiteLLs.(?<branch>.*)/gi;
my $branch_name=$out_file;
my %gene_position;
open (MATCHIN, $gene_boundary) or die "Can't open the file $gene_boundary: $!";
  while (my $content=<MATCHIN>) { 
	chomp $content;
	$content=~s/ //g;
 	next unless $content=~m/.*,(?<id>.+?)=(?<start>\d+)-(?<end>\d+)/gi;
    my $gene_name=$+{id};
    my $gene_start=$+{start};
    my $gene_end=$+{end};
    my @gene_sites=($gene_start..$gene_end);
	my $rela_position=0;
    foreach  my $gene_site( @gene_sites) {$rela_position++; @{$gene_position{$gene_site}}=($gene_name,$rela_position);}		 
  }
close MATCHIN;

my %site_hash;
my %biggest_site;
my $sites_no;
my @trees;
open (IN, $infile) or die "Can't open the file $infile: $!";
while (my $content=<IN>)  {
	 chomp $content;
	 $content=~s/\t+/ /gi;
	# if ($content=~/\s+\d+\s+(\d+)/gi) {$sites_no=$2;}
	 next unless $content=~m/^(?<tre>t\w+\d+)\s+(?<lns>.*)/gi;
	 my $tree_name=$+{tre};
	 my $lns_content=$+{lns};
     my @site_lns=split(/\s+/,$lns_content); 
	 $tree_name=~s/tree/tr/gi;
	 push  @trees, $tree_name;
	 my $site=0;
     foreach my $site_ln (@site_lns) {
		  $site++;
		  push @{$site_hash{$site}}, $site_ln;

          ## recognize putative site with lighest value ##
		  if (exists $biggest_site{$site}) {
			  if ($site_ln>$biggest_site{$site}[1]) { @{$biggest_site{$site}}=($tree_name,$site_ln);}
		  }else{@{$biggest_site{$site}}=($tree_name,$site_ln);}

      }	 
}
close IN;

print "Reading your data...\n";
my $trees_no=scalar @trees;
if ($trees_no>3) { print "Please edit the scripts, since they only accept no more than 3 hypotheses";}

my $sites_no_in_gene_partition=scalar keys %gene_position;
my $sites_no_in_sitelnlk=scalar keys %site_hash;
if ($sites_no_in_gene_partition<=>$sites_no_in_sitelnlk) { print "Please go to check $gene_boundary and $infile files, they contain different numbers of sites\n";
}
else{
my %gene_hash;
foreach my $site (sort { $a <=> $b } keys %site_hash) {
   my $gene=$gene_position{$site}[0];

   if ($trees_no==2) {
     if (exists $gene_hash{$gene}) {
	 my $gene_ln_t1=$gene_hash{$gene}[0]+@{$site_hash{$site}}[0];
	 my $gene_ln_t2=$gene_hash{$gene}[1]+@{$site_hash{$site}}[1];
	 @{$gene_hash{$gene}}=($gene_ln_t1,$gene_ln_t2);
	 }else{@{$gene_hash{$gene}}=(@{$site_hash{$site}}[0], @{$site_hash{$site}}[1]);}
   }

   elsif ($trees_no==3) {
     if (exists $gene_hash{$gene}) {
	 my $gene_ln_t1=$gene_hash{$gene}[0]+@{$site_hash{$site}}[0];
	 my $gene_ln_t2=$gene_hash{$gene}[1]+@{$site_hash{$site}}[1];
	 my $gene_ln_t3=$gene_hash{$gene}[2]+@{$site_hash{$site}}[2];
	 @{$gene_hash{$gene}}=($gene_ln_t1,$gene_ln_t2,$gene_ln_t3);
	 }else{@{$gene_hash{$gene}}=(@{$site_hash{$site}}[0], @{$site_hash{$site}}[1],@{$site_hash{$site}}[2]);}
   }

}

if ($trees_no==2) {
    my $output= "${branch_name}_table.txt";
   open (OUTPUT,">>", $output) or die "Can't write the file $output: $!";
   print OUTPUT "gene_id\ttree_supported\ttr1_GLS\ttr2_GLS\tdf_GLS\n";
   foreach my $gene (sort { $a cmp $b  } keys %gene_hash) { 
    if ($gene_hash{$gene}[0]>$gene_hash{$gene}[1]) { print OUTPUT "$gene\ttr1\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t",$gene_hash{$gene}[0]-$gene_hash{$gene}[1],"\n"; }
    elsif ($gene_hash{$gene}[1]>$gene_hash{$gene}[0]) { print OUTPUT "$gene\ttr2\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t",$gene_hash{$gene}[0]-$gene_hash{$gene}[1],"\n"; }
   } 
  close OUTPUT;
}

elsif ($trees_no==3) {
   my $output= "${branch_name}_table.txt";
   open (OUTPUT,">>", $output) or die "Can't write the file $output: $!";
   print OUTPUT "gene_id\ttree_supported\ttr1_GLS\ttr2_GLS\ttr3_GLS\n";
   foreach my $gene (sort { $a cmp $b  } keys %gene_hash) { 
    if ($gene_hash{$gene}[0]>$gene_hash{$gene}[1] and $gene_hash{$gene}[0]>$gene_hash{$gene}[2]) { print OUTPUT "$gene\ttr1\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t$gene_hash{$gene}[2]\n"; }
    elsif ($gene_hash{$gene}[1]>$gene_hash{$gene}[0] and $gene_hash{$gene}[1]>$gene_hash{$gene}[2]) { print OUTPUT "$gene\ttr2\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t$gene_hash{$gene}[2]\n"; }
    elsif ($gene_hash{$gene}[2]>$gene_hash{$gene}[0] and $gene_hash{$gene}[2]>$gene_hash{$gene}[1]) { print OUTPUT "$gene\ttr3\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t$gene_hash{$gene}[2]\n"; }
   } 
  close OUTPUT;
}





}
print "done\n";

my $end_time=time;
my $duration=($end_time-$start_time)/60;
print"Execution time: $duration min.\n";
